package com.sh.product.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class cateDTO {

	String loc_code;
	String detail_loc;
}
