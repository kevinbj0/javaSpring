package com.sh.login.domain;

import lombok.Data;

@Data
public class updateHeatDTO {

	private String user_heat;
	private String user_code;
}
